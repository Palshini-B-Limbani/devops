# Devops_midterm_assignment

Assignment 1:
      2. Developing and deploying a Node.js app from Docker to Kubernetes
      
Assignment 2:
      
Assignment 3:
        5. Add users to EC2 instances with SSH Access – Ansible
